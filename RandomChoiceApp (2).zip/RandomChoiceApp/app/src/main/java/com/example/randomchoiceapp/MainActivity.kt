
package com.example.randomchoiceapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.randomchoiceapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnChoose.setOnClickListener {
            val w1 = binding.etWord1.text.toString()
            val w2 = binding.etWord2.text.toString()
            val w3 = binding.etWord3.text.toString()
            val w4 = binding.etWord4.text.toString()

            val list = listOf(w1, w2, w3, w4).filter { it.isNotEmpty() }

            if (list.isEmpty()) {
                binding.tvResult.text = "Digite pelo menos uma palavra!"
            } else {
                val result = list.random()
                binding.tvResult.text = "A escolha perfeita é: $result"
            }
        }
    }
}
